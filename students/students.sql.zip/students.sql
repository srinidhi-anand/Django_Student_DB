-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 07, 2021 at 03:15 PM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `students`
--
CREATE DATABASE IF NOT EXISTS `students` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `students`;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE IF NOT EXISTS `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE IF NOT EXISTS `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE IF NOT EXISTS `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add user', 4, 'add_user'),
(14, 'Can change user', 4, 'change_user'),
(15, 'Can delete user', 4, 'delete_user'),
(16, 'Can view user', 4, 'view_user'),
(17, 'Can add content type', 5, 'add_contenttype'),
(18, 'Can change content type', 5, 'change_contenttype'),
(19, 'Can delete content type', 5, 'delete_contenttype'),
(20, 'Can view content type', 5, 'view_contenttype'),
(21, 'Can add session', 6, 'add_session'),
(22, 'Can change session', 6, 'change_session'),
(23, 'Can delete session', 6, 'delete_session'),
(24, 'Can view session', 6, 'view_session');

-- --------------------------------------------------------

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
CREATE TABLE IF NOT EXISTS `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
CREATE TABLE IF NOT EXISTS `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
CREATE TABLE IF NOT EXISTS `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `course_db`
--

DROP TABLE IF EXISTS `course_db`;
CREATE TABLE IF NOT EXISTS `course_db` (
  `Course` text NOT NULL,
  `Student_id` int(250) NOT NULL,
  `Academic_year` varchar(250) NOT NULL,
  `Semester` varchar(250) NOT NULL,
  `Marks` float NOT NULL,
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=55 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `course_db`
--

INSERT INTO `course_db` (`Course`, `Student_id`, `Academic_year`, `Semester`, `Marks`, `id`) VALUES
('Course_1', 1, '2019-2020', '2', 81.5, 1),
('Course_2', 1, '2019-2020', '2', 81.5, 2),
('Course_3', 1, '2019-2020', '2', 81.5, 3),
('Course_4', 1, '2019-2020', '2', 81.5, 4),
('Course_5', 1, '2019-2020', '2', 81.5, 5),
('Course_6', 1, '2019-2020', '2', 81.5, 6),
('Course_1', 1, '2019-2020', '3', 81.5, 7),
('Course_2', 1, '2019-2020', '3', 81.5, 8),
('Course_3', 1, '2019-2020', '3', 81.5, 9),
('Course_4', 1, '2019-2020', '3', 81.5, 10),
('Course_5', 1, '2019-2020', '3', 81.5, 11),
('Course_6', 1, '2019-2020', '3', 81.5, 12),
('Course_1', 1, '2019-2020', '4', 81.5, 13),
('Course_2', 1, '2019-2020', '4', 81.5, 14),
('Course_3', 1, '2019-2020', '4', 81.5, 15),
('Course_4', 1, '2019-2020', '4', 81.5, 16),
('Course_5', 1, '2019-2020', '4', 81.5, 17),
('Course_6', 1, '2019-2020', '4', 81.5, 18),
('Course_2', 2, '2019-2020', '2', 81.5, 19),
('Course_3', 2, '2019-2020', '2', 81.5, 20),
('Course_4', 2, '2019-2020', '2', 81.5, 21),
('Course_5', 2, '2019-2020', '2', 81.5, 22),
('Course_6', 2, '2019-2020', '2', 81.5, 23),
('Course_1', 2, '2019-2020', '3', 81.5, 24),
('Course_2', 2, '2019-2020', '3', 81.5, 25),
('Course_3', 2, '2019-2020', '3', 81.5, 26),
('Course_4', 2, '2019-2020', '3', 81.5, 27),
('Course_5', 2, '2019-2020', '3', 81.5, 28),
('Course_6', 2, '2019-2020', '3', 81.5, 29),
('Course_1', 2, '2019-2020', '4', 81.5, 30),
('Course_2', 2, '2019-2020', '4', 81.5, 31),
('Course_3', 2, '2019-2020', '4', 81.5, 32),
('Course_4', 2, '2019-2020', '4', 81.5, 33),
('Course_5', 2, '2019-2020', '4', 81.5, 34),
('Course_6', 2, '2019-2020', '4', 81.5, 35),
('Course_2', 3, '2019-2020', '2', 81.5, 36),
('Course_3', 3, '2019-2020', '2', 81.5, 37),
('Course_4', 3, '2019-2020', '2', 81.5, 38),
('Course_5', 3, '2019-2020', '2', 81.5, 39),
('Course_6', 3, '2019-2020', '2', 81.5, 40),
('Course_1', 3, '2019-2020', '3', 81.5, 41),
('Course_2', 3, '2019-2020', '3', 81.5, 42),
('Course_3', 3, '2019-2020', '3', 81.5, 43),
('Course_4', 3, '2019-2020', '3', 81.5, 44),
('Course_5', 3, '2019-2020', '3', 81.5, 45),
('Course_6', 3, '2019-2020', '3', 81.5, 46),
('Course_1', 3, '2019-2020', '4', 81.5, 47),
('Course_2', 3, '2019-2020', '4', 81.5, 48),
('Course_3', 3, '2019-2020', '4', 81.5, 49),
('Course_4', 3, '2019-2020', '4', 81.5, 50),
('Course_5', 3, '2019-2020', '4', 81.5, 51),
('Course_6', 3, '2019-2020', '4', 81.5, 52),
('Course_1', 3, '2019-2020', '2', 81.5, 53),
('Course_1', 2, '2019-2020', '2', 81.5, 54);

-- --------------------------------------------------------

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE IF NOT EXISTS `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE IF NOT EXISTS `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(2, 'auth', 'permission'),
(3, 'auth', 'group'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session');

-- --------------------------------------------------------

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE IF NOT EXISTS `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2021-02-07 02:18:23.217738'),
(2, 'auth', '0001_initial', '2021-02-07 02:18:24.110780'),
(3, 'admin', '0001_initial', '2021-02-07 02:18:27.303428'),
(4, 'admin', '0002_logentry_remove_auto_add', '2021-02-07 02:18:28.299466'),
(5, 'admin', '0003_logentry_add_action_flag_choices', '2021-02-07 02:18:28.308013'),
(6, 'contenttypes', '0002_remove_content_type_name', '2021-02-07 02:18:28.501964'),
(7, 'auth', '0002_alter_permission_name_max_length', '2021-02-07 02:18:28.609255'),
(8, 'auth', '0003_alter_user_email_max_length', '2021-02-07 02:18:28.760107'),
(9, 'auth', '0004_alter_user_username_opts', '2021-02-07 02:18:28.770080'),
(10, 'auth', '0005_alter_user_last_login_null', '2021-02-07 02:18:28.868069'),
(11, 'auth', '0006_require_contenttypes_0002', '2021-02-07 02:18:28.872056'),
(12, 'auth', '0007_alter_validators_add_error_messages', '2021-02-07 02:18:28.881042'),
(13, 'auth', '0008_alter_user_username_max_length', '2021-02-07 02:18:29.073443'),
(14, 'auth', '0009_alter_user_last_name_max_length', '2021-02-07 02:18:29.178136'),
(15, 'auth', '0010_alter_group_name_max_length', '2021-02-07 02:18:29.313521'),
(16, 'auth', '0011_update_proxy_permissions', '2021-02-07 02:18:29.326444'),
(17, 'auth', '0012_alter_user_first_name_max_length', '2021-02-07 02:18:29.421053'),
(18, 'sessions', '0001_initial', '2021-02-07 02:18:29.570746');

-- --------------------------------------------------------

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE IF NOT EXISTS `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `student_db`
--

DROP TABLE IF EXISTS `student_db`;
CREATE TABLE IF NOT EXISTS `student_db` (
  `Id` int(11) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Roll_No` varchar(250) NOT NULL,
  `College` varchar(250) NOT NULL,
  UNIQUE KEY `Id` (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `student_db`
--

INSERT INTO `student_db` (`Id`, `Name`, `Roll_No`, `College`) VALUES
(1, 'Karthik', '00001', 'SSN College of Engineering'),
(2, 'Bharath', '00002', 'SSN College of Engineering'),
(3, 'Divya', '00003', 'SSN College of Engineering');

-- --------------------------------------------------------

--
-- Table structure for table `tp_sem_2`
--

DROP TABLE IF EXISTS `tp_sem_2`;
CREATE TABLE IF NOT EXISTS `tp_sem_2` (
  `Id` int(250) NOT NULL AUTO_INCREMENT,
  `Course` varchar(250) NOT NULL,
  `Student_id` int(250) NOT NULL,
  `Academic_year` varchar(250) NOT NULL,
  `Semester` varchar(250) NOT NULL,
  `Par_course` varchar(250) NOT NULL,
  `Marks` float NOT NULL,
  UNIQUE KEY `Id` (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tp_sem_2`
--

INSERT INTO `tp_sem_2` (`Id`, `Course`, `Student_id`, `Academic_year`, `Semester`, `Par_course`, `Marks`) VALUES
(1, 'TestPaper_1', 3, '2019-2020', '2', 'Course_1', 91.6),
(2, 'TestPaper_2', 3, '2019-2020', '2', 'Course_1', 98.3),
(3, 'TestPaper_3', 3, '2019-2020', '2', 'Course_1', 71.1),
(4, 'TestPaper_4', 3, '2019-2020', '2', 'Course_1', 61.8),
(5, 'TestPaper_5', 3, '2019-2020', '2', 'Course_1', 84.7),
(6, 'TestPaper_1', 3, '2019-2020', '2', 'Course_2', 91.6),
(7, 'TestPaper_2', 3, '2019-2020', '2', 'Course_2', 98.3),
(8, 'TestPaper_3', 3, '2019-2020', '2', 'Course_2', 71.1),
(9, 'TestPaper_4', 3, '2019-2020', '2', 'Course_2', 61.8),
(10, 'TestPaper_5', 3, '2019-2020', '2', 'Course_2', 84.7),
(11, 'TestPaper_1', 3, '2019-2020', '2', 'Course_3', 91.6),
(12, 'TestPaper_2', 3, '2019-2020', '2', 'Course_3', 98.3),
(13, 'TestPaper_3', 3, '2019-2020', '2', 'Course_3', 71.1),
(14, 'TestPaper_4', 3, '2019-2020', '2', 'Course_3', 61.8),
(15, 'TestPaper_5', 3, '2019-2020', '2', 'Course_3', 84.7),
(16, 'TestPaper_1', 3, '2019-2020', '2', 'Course_4', 91.6),
(17, 'TestPaper_2', 3, '2019-2020', '2', 'Course_4', 98.3),
(18, 'TestPaper_3', 3, '2019-2020', '2', 'Course_4', 71.1),
(19, 'TestPaper_4', 3, '2019-2020', '2', 'Course_4', 61.8),
(20, 'TestPaper_5', 3, '2019-2020', '2', 'Course_4', 84.7),
(21, 'TestPaper_1', 3, '2019-2020', '2', 'Course_5', 91.6),
(22, 'TestPaper_2', 3, '2019-2020', '2', 'Course_5', 98.3),
(23, 'TestPaper_3', 3, '2019-2020', '2', 'Course_5', 71.1),
(24, 'TestPaper_4', 3, '2019-2020', '2', 'Course_5', 61.8),
(25, 'TestPaper_5', 3, '2019-2020', '2', 'Course_5', 84.7),
(26, 'TestPaper_1', 3, '2019-2020', '2', 'Course_6', 91.6),
(27, 'TestPaper_2', 3, '2019-2020', '2', 'Course_6', 98.3),
(28, 'TestPaper_3', 3, '2019-2020', '2', 'Course_6', 71.1),
(29, 'TestPaper_4', 3, '2019-2020', '2', 'Course_6', 61.8),
(30, 'TestPaper_5', 3, '2019-2020', '2', 'Course_6', 84.7),
(31, 'TestPaper_1', 2, '2019-2020', '2', 'Course_1', 91.6),
(32, 'TestPaper_2', 2, '2019-2020', '2', 'Course_1', 98.3),
(33, 'TestPaper_3', 2, '2019-2020', '2', 'Course_1', 71.1),
(34, 'TestPaper_4', 2, '2019-2020', '2', 'Course_1', 61.8),
(35, 'TestPaper_5', 2, '2019-2020', '2', 'Course_1', 84.7),
(36, 'TestPaper_1', 2, '2019-2020', '2', 'Course_2', 91.6),
(37, 'TestPaper_2', 2, '2019-2020', '2', 'Course_2', 98.3),
(38, 'TestPaper_3', 2, '2019-2020', '2', 'Course_2', 71.1),
(39, 'TestPaper_4', 2, '2019-2020', '2', 'Course_2', 61.8),
(40, 'TestPaper_5', 2, '2019-2020', '2', 'Course_2', 84.7),
(41, 'TestPaper_1', 2, '2019-2020', '2', 'Course_3', 91.6),
(42, 'TestPaper_2', 2, '2019-2020', '2', 'Course_3', 98.3),
(43, 'TestPaper_3', 2, '2019-2020', '2', 'Course_3', 71.1),
(44, 'TestPaper_4', 2, '2019-2020', '2', 'Course_3', 61.8),
(45, 'TestPaper_5', 2, '2019-2020', '2', 'Course_3', 84.7),
(46, 'TestPaper_1', 2, '2019-2020', '2', 'Course_4', 91.6),
(47, 'TestPaper_2', 2, '2019-2020', '2', 'Course_4', 98.3),
(48, 'TestPaper_3', 2, '2019-2020', '2', 'Course_4', 71.1),
(49, 'TestPaper_4', 2, '2019-2020', '2', 'Course_4', 61.8),
(50, 'TestPaper_5', 2, '2019-2020', '2', 'Course_4', 84.7),
(51, 'TestPaper_1', 2, '2019-2020', '2', 'Course_5', 91.6),
(52, 'TestPaper_2', 2, '2019-2020', '2', 'Course_5', 98.3),
(53, 'TestPaper_3', 2, '2019-2020', '2', 'Course_5', 71.1),
(54, 'TestPaper_4', 2, '2019-2020', '2', 'Course_5', 61.8),
(55, 'TestPaper_5', 2, '2019-2020', '2', 'Course_5', 84.7),
(56, 'TestPaper_1', 2, '2019-2020', '2', 'Course_6', 91.6),
(57, 'TestPaper_2', 2, '2019-2020', '2', 'Course_6', 98.3),
(58, 'TestPaper_3', 2, '2019-2020', '2', 'Course_6', 71.1),
(59, 'TestPaper_4', 2, '2019-2020', '2', 'Course_6', 61.8),
(60, 'TestPaper_5', 2, '2019-2020', '2', 'Course_6', 84.7),
(61, 'TestPaper_1', 1, '2019-2020', '2', 'Course_1', 91.6),
(62, 'TestPaper_2', 1, '2019-2020', '2', 'Course_1', 98.3),
(63, 'TestPaper_3', 1, '2019-2020', '2', 'Course_1', 71.1),
(64, 'TestPaper_4', 1, '2019-2020', '2', 'Course_1', 61.8),
(65, 'TestPaper_5', 1, '2019-2020', '2', 'Course_1', 84.7),
(66, 'TestPaper_1', 1, '2019-2020', '2', 'Course_2', 91.6),
(67, 'TestPaper_2', 1, '2019-2020', '2', 'Course_2', 98.3),
(68, 'TestPaper_3', 1, '2019-2020', '2', 'Course_2', 71.1),
(69, 'TestPaper_4', 1, '2019-2020', '2', 'Course_2', 61.8),
(70, 'TestPaper_5', 1, '2019-2020', '2', 'Course_2', 84.7),
(71, 'TestPaper_1', 1, '2019-2020', '2', 'Course_3', 91.6),
(72, 'TestPaper_2', 1, '2019-2020', '2', 'Course_3', 98.3),
(73, 'TestPaper_3', 1, '2019-2020', '2', 'Course_3', 71.1),
(74, 'TestPaper_4', 1, '2019-2020', '2', 'Course_3', 61.8),
(75, 'TestPaper_5', 1, '2019-2020', '2', 'Course_3', 84.7),
(76, 'TestPaper_1', 1, '2019-2020', '2', 'Course_4', 91.6),
(77, 'TestPaper_2', 1, '2019-2020', '2', 'Course_4', 98.3),
(78, 'TestPaper_3', 1, '2019-2020', '2', 'Course_4', 71.1),
(79, 'TestPaper_4', 1, '2019-2020', '2', 'Course_4', 61.8),
(80, 'TestPaper_5', 1, '2019-2020', '2', 'Course_4', 84.7),
(81, 'TestPaper_1', 1, '2019-2020', '2', 'Course_5', 91.6),
(82, 'TestPaper_2', 1, '2019-2020', '2', 'Course_5', 98.3),
(83, 'TestPaper_3', 1, '2019-2020', '2', 'Course_5', 71.1),
(84, 'TestPaper_4', 1, '2019-2020', '2', 'Course_5', 61.8),
(85, 'TestPaper_5', 1, '2019-2020', '2', 'Course_5', 84.7),
(86, 'TestPaper_1', 1, '2019-2020', '2', 'Course_6', 91.6),
(87, 'TestPaper_2', 1, '2019-2020', '2', 'Course_6', 98.3),
(88, 'TestPaper_3', 1, '2019-2020', '2', 'Course_6', 71.1),
(89, 'TestPaper_4', 1, '2019-2020', '2', 'Course_6', 61.8),
(90, 'TestPaper_5', 1, '2019-2020', '2', 'Course_6', 84.7);

-- --------------------------------------------------------

--
-- Table structure for table `tp_sem_3`
--

DROP TABLE IF EXISTS `tp_sem_3`;
CREATE TABLE IF NOT EXISTS `tp_sem_3` (
  `Id` int(250) NOT NULL AUTO_INCREMENT,
  `Course` varchar(250) NOT NULL,
  `Student_id` int(250) NOT NULL,
  `Academic_year` varchar(250) NOT NULL,
  `Semester` varchar(250) NOT NULL,
  `Par_course` varchar(250) NOT NULL,
  `Marks` float NOT NULL,
  UNIQUE KEY `Id` (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tp_sem_3`
--

INSERT INTO `tp_sem_3` (`Id`, `Course`, `Student_id`, `Academic_year`, `Semester`, `Par_course`, `Marks`) VALUES
(1, 'TestPaper_1', 3, '2019-2020', '3', 'Course_1', 91.6),
(2, 'TestPaper_2', 3, '2019-2020', '3', 'Course_1', 98.3),
(3, 'TestPaper_3', 3, '2019-2020', '3', 'Course_1', 71.1),
(4, 'TestPaper_4', 3, '2019-2020', '3', 'Course_1', 61.8),
(5, 'TestPaper_5', 3, '2019-2020', '3', 'Course_1', 84.7),
(6, 'TestPaper_1', 3, '2019-2020', '3', 'Course_2', 91.6),
(7, 'TestPaper_2', 3, '2019-2020', '3', 'Course_2', 98.3),
(8, 'TestPaper_3', 3, '2019-2020', '3', 'Course_2', 71.1),
(9, 'TestPaper_4', 3, '2019-2020', '3', 'Course_2', 61.8),
(10, 'TestPaper_5', 3, '2019-2020', '3', 'Course_2', 84.7),
(11, 'TestPaper_1', 3, '2019-2020', '3', 'Course_3', 91.6),
(12, 'TestPaper_2', 3, '2019-2020', '3', 'Course_3', 98.3),
(13, 'TestPaper_3', 3, '2019-2020', '3', 'Course_3', 71.1),
(14, 'TestPaper_4', 3, '2019-2020', '3', 'Course_3', 61.8),
(15, 'TestPaper_5', 3, '2019-2020', '3', 'Course_3', 84.7),
(16, 'TestPaper_1', 3, '2019-2020', '3', 'Course_4', 91.6),
(17, 'TestPaper_2', 3, '2019-2020', '3', 'Course_4', 98.3),
(18, 'TestPaper_3', 3, '2019-2020', '3', 'Course_4', 71.1),
(19, 'TestPaper_4', 3, '2019-2020', '3', 'Course_4', 61.8),
(20, 'TestPaper_5', 3, '2019-2020', '3', 'Course_4', 84.7),
(21, 'TestPaper_1', 3, '2019-2020', '3', 'Course_5', 91.6),
(22, 'TestPaper_2', 3, '2019-2020', '3', 'Course_5', 98.3),
(23, 'TestPaper_3', 3, '2019-2020', '3', 'Course_5', 71.1),
(24, 'TestPaper_4', 3, '2019-2020', '3', 'Course_5', 61.8),
(25, 'TestPaper_5', 3, '2019-2020', '3', 'Course_5', 84.7),
(26, 'TestPaper_1', 3, '2019-2020', '3', 'Course_6', 91.6),
(27, 'TestPaper_2', 3, '2019-2020', '3', 'Course_6', 98.3),
(28, 'TestPaper_3', 3, '2019-2020', '3', 'Course_6', 71.1),
(29, 'TestPaper_4', 3, '2019-2020', '3', 'Course_6', 61.8),
(30, 'TestPaper_5', 3, '2019-2020', '3', 'Course_6', 84.7),
(31, 'TestPaper_1', 2, '2019-2020', '3', 'Course_1', 91.6),
(32, 'TestPaper_2', 2, '2019-2020', '3', 'Course_1', 98.3),
(33, 'TestPaper_3', 2, '2019-2020', '3', 'Course_1', 71.1),
(34, 'TestPaper_4', 2, '2019-2020', '3', 'Course_1', 61.8),
(35, 'TestPaper_5', 2, '2019-2020', '3', 'Course_1', 84.7),
(36, 'TestPaper_1', 2, '2019-2020', '3', 'Course_2', 91.6),
(37, 'TestPaper_2', 2, '2019-2020', '3', 'Course_2', 98.3),
(38, 'TestPaper_3', 2, '2019-2020', '3', 'Course_2', 71.1),
(39, 'TestPaper_4', 2, '2019-2020', '3', 'Course_2', 61.8),
(40, 'TestPaper_5', 2, '2019-2020', '3', 'Course_2', 84.7),
(41, 'TestPaper_1', 2, '2019-2020', '3', 'Course_3', 91.6),
(42, 'TestPaper_2', 2, '2019-2020', '3', 'Course_3', 98.3),
(43, 'TestPaper_3', 2, '2019-2020', '3', 'Course_3', 71.1),
(44, 'TestPaper_4', 2, '2019-2020', '3', 'Course_3', 61.8),
(45, 'TestPaper_5', 2, '2019-2020', '3', 'Course_3', 84.7),
(46, 'TestPaper_1', 2, '2019-2020', '3', 'Course_4', 91.6),
(47, 'TestPaper_2', 2, '2019-2020', '3', 'Course_4', 98.3),
(48, 'TestPaper_3', 2, '2019-2020', '3', 'Course_4', 71.1),
(49, 'TestPaper_4', 2, '2019-2020', '3', 'Course_4', 61.8),
(50, 'TestPaper_5', 2, '2019-2020', '3', 'Course_4', 84.7),
(51, 'TestPaper_1', 2, '2019-2020', '3', 'Course_5', 91.6),
(52, 'TestPaper_2', 2, '2019-2020', '3', 'Course_5', 98.3),
(53, 'TestPaper_3', 2, '2019-2020', '3', 'Course_5', 71.1),
(54, 'TestPaper_4', 2, '2019-2020', '3', 'Course_5', 61.8),
(55, 'TestPaper_5', 2, '2019-2020', '3', 'Course_5', 84.7),
(56, 'TestPaper_1', 2, '2019-2020', '3', 'Course_6', 91.6),
(57, 'TestPaper_2', 2, '2019-2020', '3', 'Course_6', 98.3),
(58, 'TestPaper_3', 2, '2019-2020', '3', 'Course_6', 71.1),
(59, 'TestPaper_4', 2, '2019-2020', '3', 'Course_6', 61.8),
(60, 'TestPaper_5', 2, '2019-2020', '3', 'Course_6', 84.7),
(61, 'TestPaper_1', 1, '2019-2020', '3', 'Course_1', 91.6),
(62, 'TestPaper_2', 1, '2019-2020', '3', 'Course_1', 98.3),
(63, 'TestPaper_3', 1, '2019-2020', '3', 'Course_1', 71.1),
(64, 'TestPaper_4', 1, '2019-2020', '3', 'Course_1', 61.8),
(65, 'TestPaper_5', 1, '2019-2020', '3', 'Course_1', 84.7),
(66, 'TestPaper_1', 1, '2019-2020', '3', 'Course_2', 91.6),
(67, 'TestPaper_2', 1, '2019-2020', '3', 'Course_2', 98.3),
(68, 'TestPaper_3', 1, '2019-2020', '3', 'Course_2', 71.1),
(69, 'TestPaper_4', 1, '2019-2020', '3', 'Course_2', 61.8),
(70, 'TestPaper_5', 1, '2019-2020', '3', 'Course_2', 84.7),
(71, 'TestPaper_1', 1, '2019-2020', '3', 'Course_3', 91.6),
(72, 'TestPaper_2', 1, '2019-2020', '3', 'Course_3', 98.3),
(73, 'TestPaper_3', 1, '2019-2020', '3', 'Course_3', 71.1),
(74, 'TestPaper_4', 1, '2019-2020', '3', 'Course_3', 61.8),
(75, 'TestPaper_5', 1, '2019-2020', '3', 'Course_3', 84.7),
(76, 'TestPaper_1', 1, '2019-2020', '3', 'Course_4', 91.6),
(77, 'TestPaper_2', 1, '2019-2020', '3', 'Course_4', 98.3),
(78, 'TestPaper_3', 1, '2019-2020', '3', 'Course_4', 71.1),
(79, 'TestPaper_4', 1, '2019-2020', '3', 'Course_4', 61.8),
(80, 'TestPaper_5', 1, '2019-2020', '3', 'Course_4', 84.7),
(81, 'TestPaper_1', 1, '2019-2020', '3', 'Course_5', 91.6),
(82, 'TestPaper_2', 1, '2019-2020', '3', 'Course_5', 98.3),
(83, 'TestPaper_3', 1, '2019-2020', '3', 'Course_5', 71.1),
(84, 'TestPaper_4', 1, '2019-2020', '3', 'Course_5', 61.8),
(85, 'TestPaper_5', 1, '2019-2020', '3', 'Course_5', 84.7),
(86, 'TestPaper_1', 1, '2019-2020', '3', 'Course_6', 91.6),
(87, 'TestPaper_2', 1, '2019-2020', '3', 'Course_6', 98.3),
(88, 'TestPaper_3', 1, '2019-2020', '3', 'Course_6', 71.1),
(89, 'TestPaper_4', 1, '2019-2020', '3', 'Course_6', 61.8),
(90, 'TestPaper_5', 1, '2019-2020', '3', 'Course_6', 84.7);

-- --------------------------------------------------------

--
-- Table structure for table `tp_sem_4`
--

DROP TABLE IF EXISTS `tp_sem_4`;
CREATE TABLE IF NOT EXISTS `tp_sem_4` (
  `Id` int(250) NOT NULL AUTO_INCREMENT,
  `Course` varchar(250) NOT NULL,
  `Student_id` int(250) NOT NULL,
  `Academic_year` varchar(250) NOT NULL,
  `Semester` varchar(250) NOT NULL,
  `Par_course` varchar(250) NOT NULL,
  `Marks` float NOT NULL,
  UNIQUE KEY `Id` (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=181 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tp_sem_4`
--

INSERT INTO `tp_sem_4` (`Id`, `Course`, `Student_id`, `Academic_year`, `Semester`, `Par_course`, `Marks`) VALUES
(1, 'TestPaper_1', 3, '2019-2020', '4', 'Course_1', 91.6),
(2, 'TestPaper_2', 3, '2019-2020', '4', 'Course_1', 98.3),
(3, 'TestPaper_3', 3, '2019-2020', '4', 'Course_1', 71.1),
(4, 'TestPaper_4', 3, '2019-2020', '4', 'Course_1', 61.8),
(5, 'TestPaper_5', 3, '2019-2020', '4', 'Course_1', 84.7),
(6, 'TestPaper_1', 3, '2019-2020', '4', 'Course_2', 91.6),
(7, 'TestPaper_2', 3, '2019-2020', '4', 'Course_2', 98.3),
(8, 'TestPaper_3', 3, '2019-2020', '4', 'Course_2', 71.1),
(9, 'TestPaper_4', 3, '2019-2020', '4', 'Course_2', 61.8),
(10, 'TestPaper_5', 3, '2019-2020', '4', 'Course_2', 84.7),
(11, 'TestPaper_1', 3, '2019-2020', '4', 'Course_3', 91.6),
(12, 'TestPaper_2', 3, '2019-2020', '4', 'Course_3', 98.3),
(13, 'TestPaper_3', 3, '2019-2020', '4', 'Course_3', 71.1),
(14, 'TestPaper_4', 3, '2019-2020', '4', 'Course_3', 61.8),
(15, 'TestPaper_5', 3, '2019-2020', '4', 'Course_3', 84.7),
(16, 'TestPaper_1', 3, '2019-2020', '4', 'Course_4', 91.6),
(17, 'TestPaper_2', 3, '2019-2020', '4', 'Course_4', 98.3),
(18, 'TestPaper_3', 3, '2019-2020', '4', 'Course_4', 71.1),
(19, 'TestPaper_4', 3, '2019-2020', '4', 'Course_4', 61.8),
(20, 'TestPaper_5', 3, '2019-2020', '4', 'Course_4', 84.7),
(21, 'TestPaper_1', 3, '2019-2020', '4', 'Course_5', 91.6),
(22, 'TestPaper_2', 3, '2019-2020', '4', 'Course_5', 98.3),
(23, 'TestPaper_3', 3, '2019-2020', '4', 'Course_5', 71.1),
(24, 'TestPaper_4', 3, '2019-2020', '4', 'Course_5', 61.8),
(25, 'TestPaper_5', 3, '2019-2020', '4', 'Course_5', 84.7),
(26, 'TestPaper_1', 3, '2019-2020', '4', 'Course_6', 91.6),
(27, 'TestPaper_2', 3, '2019-2020', '4', 'Course_6', 98.3),
(28, 'TestPaper_3', 3, '2019-2020', '4', 'Course_6', 71.1),
(29, 'TestPaper_4', 3, '2019-2020', '4', 'Course_6', 61.8),
(30, 'TestPaper_5', 3, '2019-2020', '4', 'Course_6', 84.7),
(31, 'TestPaper_1', 2, '2019-2020', '4', 'Course_1', 91.6),
(32, 'TestPaper_2', 2, '2019-2020', '4', 'Course_1', 98.3),
(33, 'TestPaper_3', 2, '2019-2020', '4', 'Course_1', 71.1),
(34, 'TestPaper_4', 2, '2019-2020', '4', 'Course_1', 61.8),
(35, 'TestPaper_5', 2, '2019-2020', '4', 'Course_1', 84.7),
(36, 'TestPaper_1', 2, '2019-2020', '4', 'Course_2', 91.6),
(37, 'TestPaper_2', 2, '2019-2020', '4', 'Course_2', 98.3),
(38, 'TestPaper_3', 2, '2019-2020', '4', 'Course_2', 71.1),
(39, 'TestPaper_4', 2, '2019-2020', '4', 'Course_2', 61.8),
(40, 'TestPaper_5', 2, '2019-2020', '4', 'Course_2', 84.7),
(41, 'TestPaper_1', 2, '2019-2020', '4', 'Course_3', 91.6),
(42, 'TestPaper_2', 2, '2019-2020', '4', 'Course_3', 98.3),
(43, 'TestPaper_3', 2, '2019-2020', '4', 'Course_3', 71.1),
(44, 'TestPaper_4', 2, '2019-2020', '4', 'Course_3', 61.8),
(45, 'TestPaper_5', 2, '2019-2020', '4', 'Course_3', 84.7),
(46, 'TestPaper_1', 2, '2019-2020', '4', 'Course_4', 91.6),
(47, 'TestPaper_2', 2, '2019-2020', '4', 'Course_4', 98.3),
(48, 'TestPaper_3', 2, '2019-2020', '4', 'Course_4', 71.1),
(49, 'TestPaper_4', 2, '2019-2020', '4', 'Course_4', 61.8),
(50, 'TestPaper_5', 2, '2019-2020', '4', 'Course_4', 84.7),
(51, 'TestPaper_1', 2, '2019-2020', '4', 'Course_5', 91.6),
(52, 'TestPaper_2', 2, '2019-2020', '4', 'Course_5', 98.3),
(53, 'TestPaper_3', 2, '2019-2020', '4', 'Course_5', 71.1),
(54, 'TestPaper_4', 2, '2019-2020', '4', 'Course_5', 61.8),
(55, 'TestPaper_5', 2, '2019-2020', '4', 'Course_5', 84.7),
(56, 'TestPaper_1', 2, '2019-2020', '4', 'Course_6', 91.6),
(57, 'TestPaper_2', 2, '2019-2020', '4', 'Course_6', 98.3),
(58, 'TestPaper_3', 2, '2019-2020', '4', 'Course_6', 71.1),
(59, 'TestPaper_4', 2, '2019-2020', '4', 'Course_6', 61.8),
(60, 'TestPaper_5', 2, '2019-2020', '4', 'Course_6', 84.7),
(180, 'TestPaper_5', 1, '2019-2020', '4', 'Course_6', 84.7),
(179, 'TestPaper_4', 1, '2019-2020', '4', 'Course_6', 61.8),
(178, 'TestPaper_3', 1, '2019-2020', '4', 'Course_6', 71.1),
(177, 'TestPaper_2', 1, '2019-2020', '4', 'Course_6', 98.3),
(176, 'TestPaper_1', 1, '2019-2020', '4', 'Course_6', 91.6),
(175, 'TestPaper_5', 1, '2019-2020', '4', 'Course_5', 84.7),
(174, 'TestPaper_4', 1, '2019-2020', '4', 'Course_5', 61.8),
(173, 'TestPaper_3', 1, '2019-2020', '4', 'Course_5', 71.1),
(172, 'TestPaper_2', 1, '2019-2020', '4', 'Course_5', 98.3),
(171, 'TestPaper_1', 1, '2019-2020', '4', 'Course_5', 91.6),
(170, 'TestPaper_5', 1, '2019-2020', '4', 'Course_4', 84.7),
(169, 'TestPaper_4', 1, '2019-2020', '4', 'Course_4', 61.8),
(168, 'TestPaper_3', 1, '2019-2020', '4', 'Course_4', 71.1),
(167, 'TestPaper_2', 1, '2019-2020', '4', 'Course_4', 98.3),
(166, 'TestPaper_1', 1, '2019-2020', '4', 'Course_4', 91.6),
(165, 'TestPaper_5', 1, '2019-2020', '4', 'Course_3', 84.7),
(164, 'TestPaper_4', 1, '2019-2020', '4', 'Course_3', 61.8),
(163, 'TestPaper_3', 1, '2019-2020', '4', 'Course_3', 71.1),
(162, 'TestPaper_2', 1, '2019-2020', '4', 'Course_3', 98.3),
(161, 'TestPaper_1', 1, '2019-2020', '4', 'Course_3', 91.6),
(160, 'TestPaper_5', 1, '2019-2020', '4', 'Course_2', 84.7),
(159, 'TestPaper_4', 1, '2019-2020', '4', 'Course_2', 61.8),
(158, 'TestPaper_3', 1, '2019-2020', '4', 'Course_2', 71.1),
(157, 'TestPaper_2', 1, '2019-2020', '4', 'Course_2', 98.3),
(156, 'TestPaper_1', 1, '2019-2020', '4', 'Course_2', 91.6),
(155, 'TestPaper_5', 1, '2019-2020', '4', 'Course_1', 84.7),
(154, 'TestPaper_4', 1, '2019-2020', '4', 'Course_1', 61.8),
(153, 'TestPaper_3', 1, '2019-2020', '4', 'Course_1', 71.1),
(152, 'TestPaper_2', 1, '2019-2020', '4', 'Course_1', 98.3),
(151, 'TestPaper_1', 1, '2019-2020', '4', 'Course_1', 91.6);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
